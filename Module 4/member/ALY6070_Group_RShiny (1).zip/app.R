# ============================================================
# ALY 6070 - Group RShiny Application
# Dataset: Airbnb Vancouver Listings (November 2025)
# Business Question: What drives Airbnb listing price, revenue, and
#   guest satisfaction in Vancouver across neighbourhoods, room types,
#   property types, and hosts?
# ============================================================

library(shiny)
library(shinydashboard)
library(dplyr)
library(ggplot2)
library(leaflet)
library(scales)
library(DT)

airbnb <- read.csv("airbnb_vancouver_clean.csv", stringsAsFactors = FALSE)

num_cols <- c("latitude","longitude","accommodates","bedrooms","beds","price",
              "minimum_nights","number_of_reviews","reviews_per_month",
              "rating","est_revenue","availability_365")
airbnb[num_cols] <- lapply(airbnb[num_cols], function(x) as.numeric(as.character(x)))

room_palette <- c("Entire home/apt" = "#2C7BB6",
                  "Private room"    = "#FDAE61",
                  "Shared room"     = "#D7191C",
                  "Hotel room"      = "#1A9641")
host_palette <- c("Superhost" = "#1A9641", "Regular Host" = "#ABABAB")

ui <- dashboardPage(
  skin = "blue",
  dashboardHeader(title = "Vancouver Airbnb Group Dashboard", titleWidth = 340),
  dashboardSidebar(
    width = 300,
    sidebarMenu(
      menuItem("Overview", tabName = "overview", icon = icon("compass")),
      menuItem("Samuel - Price & Location", tabName = "samuel", icon = icon("map-location-dot")),
      menuItem("Juliana - Neighbourhoods", tabName = "juliana", icon = icon("city")),
      menuItem("Victory - Revenue & Demand", tabName = "victory", icon = icon("sack-dollar")),
      menuItem("Musa - Host Quality", tabName = "musa", icon = icon("user-check")),
      menuItem("Terry - Property & Capacity", tabName = "terry", icon = icon("building")),
      menuItem("Adebukola - Reviews & Ratings", tabName = "adebukola", icon = icon("star")),
      menuItem("Data Table", tabName = "data", icon = icon("table"))
    ),
    tags$hr(),
    selectInput("nbhd", "Neighbourhood:",
                choices = c("All neighbourhoods", sort(unique(airbnb$neighbourhood))),
                selected = "All neighbourhoods"),
    checkboxGroupInput("room", "Room type:",
                       choices = sort(unique(airbnb$room_type)),
                       selected = sort(unique(airbnb$room_type))),
    sliderInput("price_range", "Price per night ($):",
                min = floor(min(airbnb$price, na.rm = TRUE)),
                max = ceiling(max(airbnb$price, na.rm = TRUE)),
                value = c(50, 400), pre = "$"),
    helpText("ALY 6070 | Group 5")
  ),
  dashboardBody(
    tabItems(
      tabItem(
        tabName = "overview",
        fluidRow(
          box(title = "Business Case", status = "primary", solidHeader = TRUE, width = 12,
              HTML("<p style='font-size:15px'>This dashboard explores what drives Airbnb
              listing <b>price</b>, <b>revenue</b>, and <b>guest satisfaction</b> in
              Vancouver. The audience is a property investor or a city housing analyst
              who needs to understand how value varies across neighbourhoods, room types,
              property types, and host quality. The dashboard is divided into sections,
              one per group member, each answering a different part of the question.
              The data is the November 2025 Airbnb Vancouver listings export, cleaned to
              4,581 listings after removing missing prices and extreme outliers above
              $1,000 per night.</p>"))
        ),
        fluidRow(
          valueBoxOutput("kpi_listings", width = 3),
          valueBoxOutput("kpi_price", width = 3),
          valueBoxOutput("kpi_super", width = 3),
          valueBoxOutput("kpi_rating", width = 3)
        ),
        fluidRow(
          box(title = "Listings by Room Type", status = "primary", solidHeader = TRUE,
              width = 6, plotOutput("ov_room", height = 320)),
          box(title = "Price Distribution (All Listings)", status = "primary",
              solidHeader = TRUE, width = 6, plotOutput("ov_pricehist", height = 320))
        )
      ),
      tabItem(
        tabName = "samuel",
        h2("Price & Location  -  Samuel Tweneboah-Kodua Nyamekye"),
        fluidRow(
          box(title = "Listing Locations (colour = price)", status = "primary",
              solidHeader = TRUE, width = 7, leafletOutput("s_map", height = 430)),
          box(title = "Price Distribution by Room Type", status = "primary",
              solidHeader = TRUE, width = 5, plotOutput("s_box", height = 430))
        )
      ),
      tabItem(
        tabName = "juliana",
        h2("Neighbourhood Analysis  -  Juliana Takyi Gyamfua"),
        fluidRow(
          box(title = "Median Price by Top 10 Neighbourhoods", status = "primary",
              solidHeader = TRUE, width = 6, plotOutput("j_price", height = 420)),
          box(title = "Listing Count by Top 10 Neighbourhoods", status = "primary",
              solidHeader = TRUE, width = 6, plotOutput("j_count", height = 420))
        )
      ),
      tabItem(
        tabName = "victory",
        h2("Revenue & Demand  -  Victory Louis"),
        fluidRow(
          box(title = "Estimated Annual Revenue vs Number of Reviews", status = "primary",
              solidHeader = TRUE, width = 7, plotOutput("v_scatter", height = 400)),
          box(title = "Median Estimated Revenue by Room Type", status = "primary",
              solidHeader = TRUE, width = 5, plotOutput("v_rev", height = 400))
        )
      ),
      tabItem(
        tabName = "musa",
        h2("Host Quality  -  Musa Oseni Oyakhire"),
        fluidRow(
          box(title = "Superhost vs Regular Host (count)", status = "primary",
              solidHeader = TRUE, width = 6, plotOutput("m_count", height = 400)),
          box(title = "Rating Distribution by Host Type", status = "primary",
              solidHeader = TRUE, width = 6, plotOutput("m_rating", height = 400))
        )
      ),
      tabItem(
        tabName = "terry",
        h2("Property & Capacity  -  Terry Lucas Boye"),
        fluidRow(
          box(title = "Top Property Types", status = "primary",
              solidHeader = TRUE, width = 6, plotOutput("t_prop", height = 400)),
          box(title = "Price by Guest Capacity (Accommodates)", status = "primary",
              solidHeader = TRUE, width = 6, plotOutput("t_cap", height = 400))
        )
      ),
      tabItem(
        tabName = "adebukola",
        h2("Reviews & Ratings  -  Adebukola Tiwalade Fadina"),
        fluidRow(
          box(title = "Rating Distribution", status = "primary",
              solidHeader = TRUE, width = 6, plotOutput("a_hist", height = 400)),
          box(title = "Rating vs Price", status = "primary",
              solidHeader = TRUE, width = 6, plotOutput("a_scatter", height = 400))
        )
      ),
      tabItem(
        tabName = "data",
        box(title = "Filtered Listings", status = "primary", solidHeader = TRUE,
            width = 12, DTOutput("table"))
      )
    )
  )
)

server <- function(input, output, session) {

  filtered <- reactive({
    d <- airbnb
    if (input$nbhd != "All neighbourhoods") d <- d[d$neighbourhood == input$nbhd, ]
    d <- d[d$room_type %in% input$room, ]
    d <- d[d$price >= input$price_range[1] & d$price <= input$price_range[2], ]
    d
  })

  output$kpi_listings <- renderValueBox({
    valueBox(format(nrow(filtered()), big.mark = ","), "Total Listings",
             icon = icon("house"), color = "blue")
  })
  output$kpi_price <- renderValueBox({
    valueBox(paste0("$", format(round(median(filtered()$price, na.rm = TRUE)), big.mark = ",")),
             "Median Price / Night", icon = icon("dollar-sign"), color = "teal")
  })
  output$kpi_super <- renderValueBox({
    share <- mean(filtered()$superhost == "Superhost", na.rm = TRUE) * 100
    valueBox(paste0(round(share), "%"), "Superhost Share",
             icon = icon("star"), color = "yellow")
  })
  output$kpi_rating <- renderValueBox({
    valueBox(round(mean(filtered()$rating, na.rm = TRUE), 2), "Average Rating",
             icon = icon("thumbs-up"), color = "green")
  })

  output$ov_room <- renderPlot({
    d <- filtered()
    ggplot(d, aes(x = reorder(room_type, room_type, length), fill = room_type)) +
      geom_bar() + scale_fill_manual(values = room_palette) + coord_flip() +
      labs(x = NULL, y = "Number of listings") +
      theme_minimal(base_size = 13) + theme(legend.position = "none")
  })
  output$ov_pricehist <- renderPlot({
    ggplot(filtered(), aes(x = price)) +
      geom_histogram(binwidth = 25, fill = "#2C7BB6", colour = "white") +
      scale_x_continuous(labels = dollar_format()) +
      labs(x = "Price per night", y = "Count") + theme_minimal(base_size = 13)
  })

  output$s_map <- renderLeaflet({
    d <- filtered(); d <- d[!is.na(d$latitude) & !is.na(d$longitude), ]
    pal <- colorNumeric("YlOrRd", domain = d$price)
    leaflet(d) %>%
      addProviderTiles(providers$CartoDB.Positron) %>%
      setView(lng = -123.12, lat = 49.26, zoom = 11) %>%
      addCircleMarkers(lng = ~longitude, lat = ~latitude, radius = 4,
                       stroke = FALSE, fillOpacity = 0.6, color = ~pal(price),
                       popup = ~paste0("<b>", name, "</b><br>", room_type,
                                       "<br>Price: $", price, "/night")) %>%
      addLegend("bottomright", pal = pal, values = ~price, title = "Price ($)", opacity = 0.8)
  })
  output$s_box <- renderPlot({
    ggplot(filtered(), aes(x = reorder(room_type, price, FUN = median), y = price, fill = room_type)) +
      geom_boxplot(outlier.alpha = 0.2) + scale_fill_manual(values = room_palette) +
      scale_y_continuous(labels = dollar_format()) + coord_flip() +
      labs(x = NULL, y = "Price per night") +
      theme_minimal(base_size = 13) + theme(legend.position = "none")
  })

  output$j_price <- renderPlot({
    d <- filtered() %>% group_by(neighbourhood) %>%
      summarise(med = median(price, na.rm = TRUE), n = n(), .groups = "drop") %>%
      filter(n >= 5) %>% arrange(desc(med)) %>% head(10)
    ggplot(d, aes(x = reorder(neighbourhood, med), y = med, fill = med)) +
      geom_col() + scale_fill_gradient(low = "#FDAE61", high = "#2C7BB6") +
      scale_y_continuous(labels = dollar_format()) + coord_flip() +
      labs(x = NULL, y = "Median price per night") +
      theme_minimal(base_size = 13) + theme(legend.position = "none")
  })
  output$j_count <- renderPlot({
    d <- filtered() %>% count(neighbourhood, sort = TRUE) %>% head(10)
    ggplot(d, aes(x = reorder(neighbourhood, n), y = n, fill = n)) +
      geom_col() + scale_fill_gradient(low = "#C6DBEF", high = "#08519C") +
      coord_flip() + labs(x = NULL, y = "Number of listings") +
      theme_minimal(base_size = 13) + theme(legend.position = "none")
  })

  output$v_scatter <- renderPlot({
    d <- filtered(); d <- d[!is.na(d$est_revenue) & !is.na(d$number_of_reviews), ]
    ggplot(d, aes(x = number_of_reviews, y = est_revenue, colour = room_type)) +
      geom_point(alpha = 0.5, size = 2) + scale_colour_manual(values = room_palette) +
      scale_y_continuous(labels = dollar_format()) +
      labs(x = "Number of reviews", y = "Estimated annual revenue", colour = "Room type") +
      theme_minimal(base_size = 13)
  })
  output$v_rev <- renderPlot({
    d <- filtered() %>% group_by(room_type) %>%
      summarise(med = median(est_revenue, na.rm = TRUE), .groups = "drop")
    ggplot(d, aes(x = reorder(room_type, med), y = med, fill = room_type)) +
      geom_col() + scale_fill_manual(values = room_palette) +
      scale_y_continuous(labels = dollar_format()) + coord_flip() +
      labs(x = NULL, y = "Median estimated annual revenue") +
      theme_minimal(base_size = 13) + theme(legend.position = "none")
  })

  output$m_count <- renderPlot({
    d <- filtered(); d <- d[!is.na(d$superhost), ]
    ggplot(d, aes(x = superhost, fill = superhost)) +
      geom_bar() + scale_fill_manual(values = host_palette) +
      labs(x = NULL, y = "Number of listings") +
      theme_minimal(base_size = 13) + theme(legend.position = "none")
  })
  output$m_rating <- renderPlot({
    d <- filtered(); d <- d[!is.na(d$superhost) & !is.na(d$rating), ]
    ggplot(d, aes(x = superhost, y = rating, fill = superhost)) +
      geom_violin(alpha = 0.7) + geom_boxplot(width = 0.15, outlier.alpha = 0.2) +
      scale_fill_manual(values = host_palette) +
      labs(x = NULL, y = "Review score rating") +
      theme_minimal(base_size = 13) + theme(legend.position = "none")
  })

  output$t_prop <- renderPlot({
    d <- filtered() %>% count(property_type, sort = TRUE) %>% head(8)
    ggplot(d, aes(x = reorder(property_type, n), y = n, fill = n)) +
      geom_col() + scale_fill_gradient(low = "#FDAE61", high = "#D7191C") +
      coord_flip() + labs(x = NULL, y = "Number of listings") +
      theme_minimal(base_size = 13) + theme(legend.position = "none")
  })
  output$t_cap <- renderPlot({
    d <- filtered(); d <- d[d$accommodates <= 10, ]
    ggplot(d, aes(x = factor(accommodates), y = price)) +
      geom_boxplot(fill = "#2C7BB6", alpha = 0.7, outlier.alpha = 0.2) +
      scale_y_continuous(labels = dollar_format()) +
      labs(x = "Guest capacity (accommodates)", y = "Price per night") +
      theme_minimal(base_size = 13)
  })

  output$a_hist <- renderPlot({
    d <- filtered(); d <- d[!is.na(d$rating), ]
    ggplot(d, aes(x = rating)) +
      geom_histogram(binwidth = 0.1, fill = "#1A9641", colour = "white") +
      labs(x = "Review score rating", y = "Count") + theme_minimal(base_size = 13)
  })
  output$a_scatter <- renderPlot({
    d <- filtered(); d <- d[!is.na(d$rating) & !is.na(d$price), ]
    ggplot(d, aes(x = rating, y = price, colour = room_type)) +
      geom_point(alpha = 0.5, size = 2) + scale_colour_manual(values = room_palette) +
      scale_y_continuous(labels = dollar_format()) +
      labs(x = "Review score rating", y = "Price per night", colour = "Room type") +
      theme_minimal(base_size = 13)
  })

  output$table <- renderDT({
    filtered() %>%
      select(name, neighbourhood, room_type, property_type, accommodates,
             bedrooms, price, rating, superhost, est_revenue) %>%
      datatable(options = list(pageLength = 10, scrollX = TRUE), rownames = FALSE)
  })
}

shinyApp(ui = ui, server = server)
